<? include "templates/header.php";
if($userTaskType == "construct"){
	        $sqlupdatetask = "UPDATE crm_users SET task_type='list' WHERE id='{$userID}'";
            $resultupdatetask = mysqli_query($link, $sqlupdatetask);
}
if($userTaskType == "table"){
	        $sqlupdatetask = "UPDATE crm_users SET task_type='list' WHERE id='{$userID}'";
            $resultupdatetask = mysqli_query($link, $sqlupdatetask);
}
if($userTaskType == null){
		    $sqlupdatetask = "UPDATE crm_users SET task_type='list' WHERE id='{$userID}'";
            $resultupdatetask = mysqli_query($link, $sqlupdatetask);
}

if ($_POST['submit'] == 'newsadd') {
    $addtitle = $_POST['titleadd'];
    $addtext = $_POST['textadd'];
    $sql = "INSERT INTO `crm_news` (title, text, author, date) VALUES ('{$addtitle}','{$addtext}','{$userID}', '{$timeNowUNIXFormat}')";
    $result = mysqli_query($link, $sql);
    //header('Location: http://crm.terrangroup.biz/index.php?result=1305');
    echo '<meta http-equiv="refresh" content="0;URL=http://crm.terrangroup.biz/index.php?result=1305" />';
}
if (is_numeric($_GET['result'])) {
    if(isset($_GET['result'])){
        if($_GET['result'] == '1305'){
            ?>
            <div class="container-fluid"><div class="alert alert-success" role="alert">
                    TerranCRM: <?=$lang['the_task_was_added_successfully']?>
                </div></div>
        <?}}}?>
        <!-- Begin Page Content -->
        <div class="container-fluid">
<!-- ASTED: новый формат управления задачами -->
<div class="row">
    <div class="col-md-8">
    <h1 class="h3 mb-0 text-gray-800"><?=$lang['tasks']?></h1>
    </div>
<div class="col-md-4">
    <div style="
    background-color: #302e2e;
    padding: 10px;
    margin-bottom: 10px;
    border-radius: 4px;
    text-align: center;
">
<div>Управление отображением</div>
<a href="/asted/tasks-construct/" class=" d-sm-inline-block btn btn-sm btn-secondary shadow-sm mt-2"><i class="fas fa-list fa-sm text-white-50"></i> <?=$lang['task_constructor']?></a>
			<a href="/asted/tasks-table/" class=" d-sm-inline-block btn btn-sm btn-secondary shadow-sm mt-2"><i class="fas fa-list fa-sm text-white-50"></i> <?=$lang['task_table']?></a>
      <a href="/asted/tasks-trash/" class=" d-sm-inline-block btn btn-sm btn-secondary shadow-sm mt-2"><i class="fas fa-list fa-sm text-white-50"></i> <?= $lang['deleted_tasks'] ?></a>
      <a href="#" class=" d-sm-inline-block btn btn-sm btn-secondary shadow-sm mt-2" data-toggle="modal" data-target="#myModal"><i class="fas fa-plus fa-sm text-white-50"></i> <?=$lang['create_task']?></a>
        
    </div>
        </div>    
</div>
<!-- ASTED: новый формат управления задачами END -->
		<?include "core/section/addtask.php";?>
    
          <!-- Content Row -->
          <div class="row">

            <!-- Content Column -->
            <div class="col-lg-12 mb-4">
		<?include "core/section/notask.php";?>
              <!-- Approach -->
<?while ($task = mysqli_fetch_assoc($result_task)) {$title = "{$task['task_name']}";$taskAutor = "{$task['task_autor']}";$taskexecutor = "{$task['task_executor']}";$id = "{$task['id']}";$taskStatus = "{$task['task_status']}";$text = "{$task['task_text']}"; 
		if($taskStatus == 0){
			$statuttask = "Открыта";
			$statustaskstule = "task_status__open";
		}
		if($taskStatus == 1){
			$statuttask = "Закрыта";
			$statustaskstule = "task_status__clouse";
		}if($taskStatus != 13){
			if($taskexecutor == $userID OR $taskAutor == $userID OR $userSessionDivisions == "1"){
?>
 <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <a href="/asted/task/<?=$id?>/"  <h6 class="m-0 font-weight-bold text-primary"><?=$title;?></h6></a> <a href="/asted/task-edit/<?=$id?>/"><i class="fas fa-fw fa-edit" style="float: right;    float: right;margin-top: 3px;margin-left: 20px;"></i></a><span class="<?=$statustaskstule?>" style="float: right;padding: 0 10px 0 10px;border-radius: 10px;"> <?=$statuttask?> </span>
                </div>
                <div class="card-body">
                  <p><?=$text?></p>
                </div>
</div><?}}}?>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->
<? include "templates/footer.php"; ?>